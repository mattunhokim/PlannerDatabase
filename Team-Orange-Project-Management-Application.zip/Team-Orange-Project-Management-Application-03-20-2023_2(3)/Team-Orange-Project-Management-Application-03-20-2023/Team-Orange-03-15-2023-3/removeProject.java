import javax.swing.*;

public class removeProject {
    private JButton removeProjectButton;
    private JPanel panel1;
}
