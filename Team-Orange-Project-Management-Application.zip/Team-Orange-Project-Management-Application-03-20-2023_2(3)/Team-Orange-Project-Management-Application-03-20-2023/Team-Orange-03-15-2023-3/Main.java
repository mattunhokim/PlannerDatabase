import java.io.File;
import java.io.IOException;

/**
 * Main Class
 */
public class Main {
    public static void main(String[] args) throws IOException {
        System.out.println("Default Message to Client\n\n");
        MyApp app = new MyApp();
        app.runApplication();
    }
}